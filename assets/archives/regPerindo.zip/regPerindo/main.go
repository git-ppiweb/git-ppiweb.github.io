package main

import (
	"fmt"
	"github.com/gorilla/mux"
	"log"
	"net/http"
	"regPerindo/controllers"
)

func main() {
	staticDir := "/assets/"
	serverPort := 8081
	serverURI := fmt.Sprintf(":%d", serverPort)

	router := mux.NewRouter().StrictSlash(true)
	router.PathPrefix(staticDir).Handler(http.StripPrefix(staticDir, http.FileServer(http.Dir("."+staticDir))))

	/*All route here*/
	/*Landing Page*/
	router.HandleFunc("/", controllers.Register)
	router.HandleFunc("/registernik", controllers.RegisterNIK)
	router.HandleFunc("/formregister", controllers.FormRegister).Methods("POST")
	router.HandleFunc("/register", controllers.SaveRegister).Methods("POST")

	/*API*/
	router.HandleFunc("/api/getkota", controllers.GetKota).Methods("POST")
	router.HandleFunc("/api/getkecamatan", controllers.GetKecamatan).Methods("POST")
	router.HandleFunc("/api/getkelurahan", controllers.GetKelurahan).Methods("POST")
	router.HandleFunc("/api/getkodepos", controllers.GetKodePos).Methods("POST")
	router.HandleFunc("/api/carikota", controllers.WilayahKota).Methods("POST")
	router.HandleFunc("/api/ceknik", controllers.CekNik).Methods("POST")
	/*End route*/

	http.Handle("/", router)
	fmt.Println("Connected to port: ", serverPort)
	log.Fatal(http.ListenAndServe(serverURI, router))
}