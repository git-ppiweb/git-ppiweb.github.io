package controllers

import (
	"fmt"
	"html/template"
	"net/http"
	"regPerindo/models"
	"strconv"
	"strings"
	"time"
)

type title struct {
	Title		string
	SubTitle	string
}

type resRegister struct {
	Nik			string
	Nama		string
	JnsKelamin	string
	TmpLahir	string
	TglLahir	string
	Prov		string
	Kota		string
	Kec			string
}

func (r resRegister) NamaKota() string {
	namaKota := models.GetNamaKota(r.Kota)
	return strings.ToUpper(namaKota)
}

func (r resRegister) LoadProvinsi() template.HTML {
	wilayahProv := models.GetWilayahProv()

	option := []string{}
	option = append(option, "<option value=''>Pilih</option>")
	var selected string
	for _, each := range wilayahProv {
		if r.Prov == each.IDWilayah {selected = " selected"} else {selected = ""}
		value := fmt.Sprintf("<option%s value='%s'>%s</option>", selected, each.IDWilayah, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	return template.HTML(strings.Join(option, ""))
}

func (r resRegister) LoadKota() template.HTML {
	wilayahKota := models.GetWilayahKotaByProv(r.Prov)

	option := []string{}
	option = append(option, "<option value=''>Pilih</option>")
	var selected string
	for _, each := range wilayahKota {
		if r.Kota == each.IDWilayah {selected = " selected"} else {selected = ""}
		value := fmt.Sprintf("<option%s value='%s'>%s</option>", selected, each.IDWilayah, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	return template.HTML(strings.Join(option, ""))
}

func (r resRegister) LoadKecamatan() template.HTML {
	wilayahKecamatan := models.GetWilayahKecamatanByKota(r.Kota)

	option := []string{}
	option = append(option, "<option value=''>Pilih</option>")
	var selected string
	for _, each := range wilayahKecamatan {
		if r.Kec == each.IDWilayah {selected = " selected"} else {selected = ""}
		value := fmt.Sprintf("<option%s value='%s'>%s</option>", selected, each.IDWilayah, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	return template.HTML(strings.Join(option, ""))
}

func (r resRegister) LoadKelurahan() template.HTML {
	wilayahKelurahan := models.GetWilayahKelurahanByKec(r.Kec)

	option := []string{}
	option = append(option, "<option value=''>Pilih</option>")
	for _, each := range wilayahKelurahan {
		value := fmt.Sprintf("<option value='%s'>%s</option>", each.IDWilayah, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	return template.HTML(strings.Join(option, ""))
}

func (r resRegister) LoadAgama() template.HTML {
	getData := models.GetData("agama")

	option := []string{}
	option = append(option, "<option value=''>Pilih</option>")
	for _, each := range getData {
		value := fmt.Sprintf("<option value='%s'>%s</option>", each.IDRespon, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	return template.HTML(strings.Join(option, ""))
}

func (r resRegister) LoadPekerjaan() template.HTML {
	getData := models.GetData("pekerjaan")

	option := []string{}
	option = append(option, "<option value=''>Pilih</option>")
	for _, each := range getData {
		value := fmt.Sprintf("<option value='%s'>%s</option>", each.IDRespon, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	return template.HTML(strings.Join(option, ""))
}

func (r resRegister) LoadKawin() template.HTML {
	getData := models.GetData("kawin")

	option := []string{}
	option = append(option, "<option value=''>Pilih</option>")
	for _, each := range getData {
		value := fmt.Sprintf("<option value='%s'>%s</option>", each.IDRespon, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	return template.HTML(strings.Join(option, ""))
}

func Register(w http.ResponseWriter, r *http.Request) {
	temp := template.Must(template.ParseFiles("templates/_head_foot.html", "templates/index.html", "templates/home.html"))

	data := struct {
		Head	title
		Content	string
	}{
		title{"Partai Perindo", "Registrasi Anggota"}, "sip",
	}

	if err := temp.ExecuteTemplate(w, "index", data); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}

func RegisterNIK(w http.ResponseWriter, r *http.Request) {
	temp := template.Must(template.ParseFiles("templates/_head_foot.html", "templates/index.html", "templates/registernik.html"))

	data := struct {
		Head	title
		Content	string
	}{
		title{"Partai Perindo", "Registrasi NIK Anggota"}, "",
	}

	if err := temp.ExecuteTemplate(w, "index", data); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}

func FormRegister(w http.ResponseWriter, r *http.Request) {
	temp := template.Must(template.ParseFiles("templates/_head_foot.html", "templates/index.html", "templates/formregister.html"))
	_ = r.ParseMultipartForm(10 << 20)

	nik := r.FormValue("nik")
	splitNik := strings.Split(nik, "")
	prov := fmt.Sprintf("%s%s", splitNik[0], splitNik[1])
	kota := fmt.Sprintf("%s%s%s%s", splitNik[0], splitNik[1], splitNik[2], splitNik[3])
	kec := fmt.Sprintf("%s%s%s%s%s%s", splitNik[0], splitNik[1], splitNik[2], splitNik[3], splitNik[4], splitNik[5])
	jk := "1"
	tgl := fmt.Sprintf("%s%s", splitNik[6], splitNik[7])
	intTgl, _ := strconv.Atoi(tgl)
	if intTgl > 31 {
		jk = "2"
		intTgl = intTgl - 40
		tgl = strconv.Itoa(intTgl)
	}
	bln := fmt.Sprintf("%s%s", splitNik[8], splitNik[9])
	thn := fmt.Sprintf("%s%s", splitNik[10], splitNik[11])
	tglParse, _ := time.Parse("02-01-06", fmt.Sprintf("%s-%s-%s", tgl, bln, thn))
	tglFull := tglParse.Format("02-01-2006")
	nama := strings.ToUpper(r.FormValue("nama"))

	respon := resRegister{
		Nik: nik,
		Nama: nama,
		JnsKelamin: jk,
		Prov: prov,
		Kota: kota,
		Kec: kec,
		TglLahir: tglFull,
		TmpLahir: kota,
	}

	data := struct {
		Head	title
		Content	resRegister
	}{
		title{"Partai Perindo", "Registrasi Anggota"}, respon,
	}

	if err := temp.ExecuteTemplate(w, "index", data); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}

func SaveRegister(w http.ResponseWriter, r *http.Request) {
	http.Redirect(w, r, "/testing", http.StatusTemporaryRedirect)
}