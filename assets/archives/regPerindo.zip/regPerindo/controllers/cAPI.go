package controllers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"regPerindo/models"
	"strings"
)

func CekNik(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	_ = r.ParseMultipartForm(10 << 20)

	nik := r.FormValue("nik")

	res := models.GetNik(nik)

	_, _ = w.Write([]byte(res))
}

func WilayahKota(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	_ = r.ParseMultipartForm(10 << 20)

	search := r.FormValue("search")

	dataWilayah := models.GetWilayahKota(search)

	_ = json.NewEncoder(w).Encode(dataWilayah)
}

func GetKota(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseMultipartForm(10 << 20)

	prov := r.FormValue("prov")

	wilayahKota := models.GetWilayahKotaByProv(prov)

	option := []string{}
	option = append(option, "<option>Pilih</option>")
	for _, each := range wilayahKota {
		value := fmt.Sprintf("<option value='%s'>%s</option>", each.IDWilayah, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	_, _ = w.Write([]byte(strings.Join(option, "")))
}

func GetKecamatan(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseMultipartForm(10 << 20)

	kota := r.FormValue("kota")

	wilayahKec := models.GetWilayahKecamatanByKota(kota)

	option := []string{}
	option = append(option, "<option>Pilih</option>")
	for _, each := range wilayahKec {
		value := fmt.Sprintf("<option value='%s'>%s</option>", each.IDWilayah, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	_, _ = w.Write([]byte(strings.Join(option, "")))
}

func GetKelurahan(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseMultipartForm(10 << 20)

	kec := r.FormValue("kec")

	wilayahKel := models.GetWilayahKelurahanByKec(kec)

	option := []string{}
	option = append(option, "<option>Pilih</option>")
	for _, each := range wilayahKel {
		value := fmt.Sprintf("<option value='%s'>%s</option>", each.IDWilayah, strings.ToUpper(each.Nama))
		option = append(option, value)
	}

	_, _ = w.Write([]byte(strings.Join(option, "")))
}

func GetKodePos(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseMultipartForm(10 << 20)

	kel := r.FormValue("kel")

	kodepos := models.GetKodePos(kel)

	_, _ = w.Write([]byte(kodepos))
}