package models

import (
	"database/sql"
	_"github.com/go-sql-driver/mysql"
	"fmt"
	"log"
)

func Connect() *sql.DB {
	dbDriver := "mysql"
	dbHostname := "localhost"
	dbPort := "3306"
	dbUsername := "root"
	dbPassword := ""
	dbName := "db_perindo3"
	dbURI := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s", dbUsername, dbPassword, dbHostname, dbPort, dbName)

	db, err := sql.Open(dbDriver, dbURI)
	if err != nil {
		log.Fatal(err)
	}

	return db
}