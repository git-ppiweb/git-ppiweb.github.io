package models

import (
	"database/sql"
	"log"
	"strings"
)

type DataWilayah struct {
	IDWilayah	string	`json:"id"`
	Nama		string	`json:"text"`
}

type DataRespon struct {
	IDRespon	string	`json:"id"`
	Nama		string	`json:"nama"`
}

func GetNik(nik string) string {
	db := Connect()
	defer db.Close()

	var id string

	status := "false"
	if err := db.QueryRow(`select id from users where is_activated='1' and nik=?`, nik).Scan(&id); err != nil {
		if err == sql.ErrNoRows {
			status = "true"
		}
	}

	return status
}

func GetNamaKota(id string) string {
	db := Connect()
	defer db.Close()

	var nama string
	if err := db.QueryRow("select kabupaten_name from perindowebsite_wilayah_kabupaten where id = ?", id).Scan(&nama); err != nil {
		return ""
	}

	return nama
}

func GetKodePos(id string) string {
	db := Connect()
	defer db.Close()

	var kodepos string
	if err := db.QueryRow("select kodepos from perindowebsite_wilayah_kelurahan where id = ?", id).Scan(&kodepos); err != nil {
		return ""
	}

	return kodepos
}

func GetWilayahProv() []DataWilayah {
	db := Connect()
	defer db.Close()

	dataWilayah := DataWilayah{}
	arrDataWilayah := []DataWilayah{}

	rows, err := db.Query("select id, provinsi_name from perindowebsite_wilayah_provinsi order by provinsi_name")
	if err != nil {
		log.Print(err)
		return arrDataWilayah
	}
	defer rows.Close()

	for rows.Next() {
		if err := rows.Scan(&dataWilayah.IDWilayah, &dataWilayah.Nama); err != nil {
			log.Print(err)
			return arrDataWilayah
		}
		arrDataWilayah = append(arrDataWilayah, dataWilayah)
	}

	return arrDataWilayah
}

func GetWilayahKotaByProv(search string) []DataWilayah {
	db := Connect()
	defer db.Close()

	dataWilayah := DataWilayah{}
	arrDataWilayah := []DataWilayah{}

	rows, err := db.Query("select id, kabupaten_name from perindowebsite_wilayah_kabupaten where provinsi_id = ? order by kabupaten_name", search)
	if err != nil {
		log.Print(err)
		return arrDataWilayah
	}
	defer rows.Close()

	for rows.Next() {
		if err := rows.Scan(&dataWilayah.IDWilayah, &dataWilayah.Nama); err != nil {
			log.Print(err)
			return arrDataWilayah
		}
		arrDataWilayah = append(arrDataWilayah, dataWilayah)
	}

	return arrDataWilayah
}

func GetWilayahKecamatanByKota(search string) []DataWilayah {
	db := Connect()
	defer db.Close()

	dataWilayah := DataWilayah{}
	arrDataWilayah := []DataWilayah{}

	rows, err := db.Query("select id, kecamatan_name from perindowebsite_wilayah_kecamatan where kabupaten_id = ? order by kecamatan_name", search)
	if err != nil {
		log.Print(err)
		return arrDataWilayah
	}
	defer rows.Close()

	for rows.Next() {
		if err := rows.Scan(&dataWilayah.IDWilayah, &dataWilayah.Nama); err != nil {
			log.Print(err)
			return arrDataWilayah
		}
		arrDataWilayah = append(arrDataWilayah, dataWilayah)
	}

	return arrDataWilayah
}

func GetWilayahKelurahanByKec(search string) []DataWilayah {
	db := Connect()
	defer db.Close()

	dataWilayah := DataWilayah{}
	arrDataWilayah := []DataWilayah{}

	rows, err := db.Query("select id, nama from perindowebsite_wilayah_kelurahan where kecamatan_id = ? order by nama", search)
	if err != nil {
		log.Print(err)
		return arrDataWilayah
	}
	defer rows.Close()

	for rows.Next() {
		if err := rows.Scan(&dataWilayah.IDWilayah, &dataWilayah.Nama); err != nil {
			log.Print(err)
			return arrDataWilayah
		}
		arrDataWilayah = append(arrDataWilayah, dataWilayah)
	}

	return arrDataWilayah
}

func GetWilayahKota(search string) []DataWilayah {
	db := Connect()
	defer db.Close()

	dataWilayah := DataWilayah{}
	arrDataWilayah := []DataWilayah{}

	rows, err := db.Query("select id, kabupaten_name from perindowebsite_wilayah_kabupaten where kabupaten_name like ? or id like ? order by kabupaten_name", "%"+search+"%", "%"+search+"%")
	if err != nil {
		log.Print(err)
		return arrDataWilayah
	}
	defer rows.Close()

	for rows.Next() {
		if err := rows.Scan(&dataWilayah.IDWilayah, &dataWilayah.Nama); err != nil {
			log.Print(err)
			return arrDataWilayah
		}
		dataWilayah.Nama = strings.ToUpper(dataWilayah.Nama)
		arrDataWilayah = append(arrDataWilayah, dataWilayah)
	}

	return arrDataWilayah
}

func GetData(param string) []DataRespon {
	db := Connect()
	defer db.Close()

	dataRespon := DataRespon{}
	arrDataRespon := []DataRespon{}

	var rows *sql.Rows
	var err error

	if param == "agama" {
		rows, err = db.Query("select id, agama_name from perindowebsite_userprofile_agama")
	} else if param == "kawin" {
		rows, err = db.Query("select id, status_kawin_name from perindowebsite_userprofile_status_kawin")
	} else if param == "pekerjaan" {
		rows, err = db.Query("select id, pekerjaan_name from perindowebsite_userprofile_pekerjaan")
	}

	if err != nil {
		log.Print(err)
		return arrDataRespon
	}
	defer rows.Close()

	for rows.Next() {
		if err := rows.Scan(&dataRespon.IDRespon, &dataRespon.Nama); err != nil {
			log.Print(err)
			return arrDataRespon
		}
		dataRespon.Nama = strings.ToUpper(dataRespon.Nama)
		arrDataRespon = append(arrDataRespon, dataRespon)
	}

	return arrDataRespon
}